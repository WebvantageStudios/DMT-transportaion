class SharedPrefsNames {
  static const String loginToken = "loginToken";
  static const String fcmToken = "firebaseFCMToken";
}
