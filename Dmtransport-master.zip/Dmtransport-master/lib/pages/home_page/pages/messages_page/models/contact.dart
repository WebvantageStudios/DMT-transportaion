import 'package:flutter/material.dart';

class Contact {
  final String name;
  final IconData icon;

  Contact(this.name, this.icon);
}
