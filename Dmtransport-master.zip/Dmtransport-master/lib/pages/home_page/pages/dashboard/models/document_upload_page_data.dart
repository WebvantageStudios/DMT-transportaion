import 'dart:io';

class DocumentUploadPageData {
  final File document;
  final String documentType;

  DocumentUploadPageData(this.document, this.documentType);
}
