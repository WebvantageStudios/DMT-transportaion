package com.dmtransport.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
