package com.dmtransport.dmtransport

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
